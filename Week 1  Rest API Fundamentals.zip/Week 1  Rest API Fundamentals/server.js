const express = require("express");

const app = express();

app.use(express.json());

const students = [
    {
        id: 1,
        name: "Ali",
        age: 20
    },
    {
        id: 2,
        name: "Sara",
        age: 21
    }
];

app.get("/", (req, res) => {
    res.json({
        message: "Welcome to my REST API"
    });
});

app.get("/students", (req, res) => {
    res.json(students);
});

app.post("/students", (req, res) => {

    const { name, age } = req.body;

    // Validation
    if (!name || !age) {
        return res.status(400).json({
            message: "Name and age are required"
        });
    }

    // Generate new ID
    const newStudent = {
        id: students.length + 1,
        name: name,
        age: age
    };

    students.push(newStudent);

    res.status(201).json({
        message: "Student added successfully",
        student: newStudent
    });
});

app.listen(3000, () => {
    console.log("Server is running on port 3000");
});